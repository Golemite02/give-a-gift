const { Client, Collection } = require("discord.js");
const config = require("../../config.json");
module.exports = async client => {

  console.log(`Bot: ${client.user.tag}\nChannels: ${client.channels.cache.size}\nServers: ${client.guilds.cache.size}\nUsers: ${client.users.cache.size}`);
  client.guilds.cache.forEach(guild => {
  console.log(`${guild.name} | ${guild.id} | ${guild.members.cache.size} |  `);
})

  let statuses = [
    `${config["Bot_Info"].prefix}help | ${client.users.cache.size} members! `,
  ]

  setInterval(function () {
    let status = statuses[Math.floor(Math.random() * statuses.length)];

    client.user.setActivity(status, { type: 'STREAMING', url: 'https://www.twitch.tv/name'})
  }, 10000)
}
