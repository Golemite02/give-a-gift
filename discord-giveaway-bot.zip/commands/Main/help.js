const { MessageEmbed, Client } = require("discord.js");
const client = require("discord.js")
const config = require("../../config.json")
module.exports = {
  config: {
    name: "help",
    description: "Get a list of bot commands.",
    usage: "help",
    category: "Main",
    accessableby: "Everyone",
    aliases: [], // To add custom aliases just type ["alias1", "alias2"].
  },
  run: async (client, message, args) => {
    let avatarOptions = {
      format: 'png',
      dynamic: true,
      size: 1024
    }

    const embed = new MessageEmbed()
.setTitle('**__Click for invite me!__**')
.setURL('https://discord.com/api/oauth2/authorize?client_id=809927708720496640&permissions=8&scope=bot')
.setColor('ffe100')
.setDescription(`
**Here is the list of all commands:**
\`gg!start <#channel_name> <duration> <winners_amount> <prize>\`
This command is for start a giveaway.

\`gg!reroll <giveaway_id/prize_name>\`
This command is for reroll a winner.

\`gg!end <giveaway_id/prize_name>\`
This command is for end a giveaway.
__Note: Ending time: **0.5s**__

\`gg!purge <messages_amount>\`
This command is for delete a specified amount of messages.
__Note: Messages Limit: **100** - Cant delete messages older than 14 days.__

\`gg!nuke\`
This command is for nuke a channel.

\`gg!ban <user_id/username#tag/@username> <reason>\`
This command is for ban an user.
__Note: Reason is optional.__

\`gg!unban <user_id/username#tag>\`
This command is for unban an user.

\`gg!modlogs <#channel_name/channel_id>\`
__Note: You need first create the channel and provide it in the command.__


`)
.setFooter('Created by Vientam#1514');
if (message.guild) {
      message.channel.send('<:heybro:750005947128348712>  **I sent you the list of commands in your DMs**');
      message.author.send(embed);
    } else {
      message.author.send(embed)
    }
  }
}