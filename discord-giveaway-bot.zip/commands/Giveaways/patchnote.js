module.exports = {
    config: {
        name: "patchnote",
        aliases: [],
        category: "Giveaways",
        description: "See the patchnote of last updates.",
        usage: "patchnote",
    },
}

    run: async (client, message, args) => {
message.channel.send('Test ');
    }