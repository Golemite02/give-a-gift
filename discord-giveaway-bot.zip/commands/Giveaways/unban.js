const { MessageEmbed } = require("discord.js")
const db = require('quick.db');

module.exports = {
    config: {
        name: "unban",
        description: "Unban a user from the server.",
        usage: "[name | tag | mention | ID] <reason> (optional)",
        category: "Giveaways",
        accessableby: "Admins",
        aliases: [],
    },
    run: async (bot, message, args) => {

        if (!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send("<a:forbidden:750012265083830348> You need `BAN_MEMBERS` permission for unban members.")

        if (!args[0]) return message.channel.send("Command usage: `gg!unban <user_id/mention/username#tag>`")
      
        let bannedMemberInfo = await message.guild.fetchBans()

        let bannedMember;
        bannedMember = bannedMemberInfo.find(b => b.user.username.toLowerCase() === args[0].toLocaleLowerCase()) || bannedMemberInfo.get(args[0]) || bannedMemberInfo.find(bm => bm.user.tag.toLowerCase() === args[0].toLocaleLowerCase());
        if (!bannedMember) return message.channel.send("Please provide a valid ID/Username#Tag or the user is not banned.")

        let reason = args.slice(1).join(" ")

        if (!message.guild.me.hasPermission("BAN_MEMBERS")) return message.channel.send("I need `BAN_MEMBERS` permission for unban members.")
         try{
            if (reason) {
                message.guild.members.unban(bannedMember.user.id, reason)
                var sembed = new MessageEmbed()
                    .setColor("FFFF00")
                    .setTitle("**Unbanned user**")
                    .setDescription(`**${bannedMember.user.tag}#${bannedMember.user.discriminator}** was unbanned.
                    `)
                message.channel.send(sembed)
            } else {
                message.guild.members.unban(bannedMember.user.id, reason)
                var sembed2 = new MessageEmbed()
                    .setColor("FFFF00")
                    .setTitle("**Unbanned user**")
                    .setDescription(`**${bannedMember.user.tag}#${user.discriminator}** was unbanned`)
                message.channel.send(sembed2)
            }
        } catch {
            
        }

        let channel = db.fetch(`modlog_${message.guild.id}`)
        if (!channel) return;

        const embed = new MessageEmbed()
          .setTitle('**Moderation - Unbanned user info:**')
          .setColor('ffe100')
          .setDescription(`
          Unbanned user: **${bannedMember.user.username}#${bannedMember.user.discriminator}**
          ID: **${bannedMember.user.id}**
          Moderator: <@${message.author.id}>
         `)
        .setFooter('Mod-logs')
        .setTimestamp();

        var sChannel = message.guild.channels.cache.get(channel)
        if (!sChannel) return;
        sChannel.send(embed)
    }
}